# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 01:33:42 2020

@author: jhasa
"""


str1 = input("Enter string 1:")

str2 = input("Enter string 2:")

opstr1 =  str2[-2:]   + str1[2:-2] + str2[0:2]
print(opstr1)

opstr2 =  str1[-2:]   + str2[2:-2] + str1[0:2]
print(opstr2)

# abcdefqwa

# gfdkghye