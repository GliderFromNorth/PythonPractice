#Author: Saurav Jha, Alias: GliderFromNorth  https://LinkedIn.com/in/gliderfromnorth
import math

l = int(input("Please Enter the length:"))
w = int(input("Please Enter the width:"))
s = int(input("Please Enter the Side of CUBE:"))
print("Total Number of CUBES can be placed in Tray are {}.".format(l*ws**2))
