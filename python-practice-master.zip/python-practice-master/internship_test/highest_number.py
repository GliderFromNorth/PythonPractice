
def highnum(l):
    num =0
    for n in l:
        if n > num: num = n
    print(num)

l = [10,15,5,23] 
highnum(l)
