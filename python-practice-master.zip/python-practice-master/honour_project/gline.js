gline = [ ['Month','umich.edu','berkeley.edu','ucdavis.edu','ufp.pt','indiana.edu','uct.ac.za','columbia.edu','etudes.org','gmail.com','mac.com'],
['2005-12',57,12,10,10,11,13,13,5,9,12],
['2006-01',96,30,31,31,29,26,23,27,17,13]
];
