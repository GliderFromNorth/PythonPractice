# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 10:28:06 2020

@author: jhasa
"""

fileconnection = open("regex_sum_531610.txt", "r")
lines = fileconnection.readlines()
header = lines[0]
field_names = header.strip().split(',')
print(field_names)
 
for row in lines[1:]:
     vals = row.strip().split(',')
     if vals[5] != "NA":
         print("{}: {}; {}".format(
                 vals[0],
                 vals[4],
                 vals[5]))
